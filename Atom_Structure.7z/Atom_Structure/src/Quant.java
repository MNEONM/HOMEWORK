import Basic_mattery.Quark;

public class Quant extends Quark {
    boolean mattery_type=true;
}
