public class Neutron extends Quant{

}
