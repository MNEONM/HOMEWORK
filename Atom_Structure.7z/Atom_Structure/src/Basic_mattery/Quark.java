package Basic_mattery;

public class Quark extends Energy{
}
