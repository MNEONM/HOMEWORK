package Basic_mattery;

public class Space {
    double distortion;
}
