package Basic_mattery;

public class Energy extends Space{
    double amount;
}
