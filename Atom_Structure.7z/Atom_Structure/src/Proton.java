public class Proton extends Quant{
}
