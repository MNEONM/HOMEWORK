public class Photon extends Quant{
    private int speed;
    Photon(String enviroment){
        if (enviroment!="Vacuum"){
            if (enviroment=="Air") {
                this.speed-=300;
            }
            if (enviroment=="Glass"){
                this.speed-=1000;
            }
        }else{
            this.speed=300000000;
        }
    }
}
