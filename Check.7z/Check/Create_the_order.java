package Check;

public class Create_the_order {
    private String name;
    private int prize;
    private int count=-1;
    private int[] array=new int[10];

    public void buy_ice_cream(){
        this.count+=1;
        this.array[this.count]=10;
    }

    public void buy_soup(){
        this.count+=1;
        this.array[this.count]=30;
    }

    Create_the_order(String name){
        this.name=name;
    }

    @Override
    public String toString() {
        int amount=0;
        for (int i = 0; i < this.array.length; i++) {
            this.prize+=this.array[i];
        }

        for (int i = 0; i < this.array.length; i++) {
            if(this.array[i]!=0){
                amount++;
            }
        }

        return "Order name: "+this.name+";\n dish amount: "+amount+";\n prize: "+this.prize;
    }
}
