package Check;

public class Main {
    public static void main(String[] args) {
        Create_the_order check1=new Create_the_order("Michael");
        check1.buy_ice_cream();
        check1.buy_ice_cream();
        check1.buy_soup();
        System.out.println(check1.toString());
    }
}
