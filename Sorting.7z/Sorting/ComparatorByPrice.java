package Sorting;

import java.util.Comparator;

public class ComparatorByPrice implements Comparator {
    @Override
    public int compare(Object o1, Object o2) {
        return ((Car)o1).price-((Car)o2).price;
    }
}
