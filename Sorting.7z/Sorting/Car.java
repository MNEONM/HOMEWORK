package Sorting;

public class Car implements Comparable{
    @Override
    public int compareTo(Object o) {
        int temp= this.speed-((Car)o).speed;

        int temp2=(temp==0)?(0):(0);

        if (temp==0){
            temp=this.model.compareTo(((Car)o).model);
            if (temp==0){
                temp=this.color.compareTo(((Car)o).color);
                return temp;
            }else{
                return temp;
            }
        }else{
            return temp;
        }


    }

    int speed;
    int price;
    String model;
    String color;
    Car(int speed,int price,String model,String color){
        this.speed=speed;
        this.price=price;
        this.model=model;
        this.color=color;
    }

    @Override
    public String toString() {
        return "Car{" +
                "speed=" + speed +
                ", price=" + price +
                ", model='" + model + '\'' +
                ", color='" + color + '\'' +
                '}';
    }
}
