package Sorting;

import java.util.Comparator;

public class ConparatorBySpeed implements Comparator {
    @Override
    public int compare(Object o1, Object o2) {
        return ((Car)o1).speed-((Car)o2).speed;
    }
}
