package Sorting;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        int[] x={3,2,8,-3,1,4,5,4};
        String[] s={"Mary","Serg","Taras","Kate"};
        Arrays.sort(x);
        for (int i:x) {
            System.out.println(i);
        }
        Car c1=new Car(500,900,"WOW","green");
        Car c2=new Car(400,300,"BMW","blue");
        Car c3=new Car(500,300,"WOW","O");
        Car c4=new Car(400,2000,"UJIJ","blue");
        Car c5=new Car(400,2000,"UJIJ","blue");
        Car c6=new Car(400,2000,"UJIJ","blue");
        Car c7=new Car(700,4000,"UJIJ","blue");


        Car[] c={c1,c2,c3,c4};
        Arrays.sort(c,new ComparatorByPrice());

        for (Car t:c) {
            System.out.println(t.toString());
        }

    }
}
